import React, { useRef, useState, useEffect, useCallback } from 'react';
import { BackHandler, Linking, SafeAreaView, View, Text, TouchableOpacity, ActivityIndicator, StyleSheet, Platform, StatusBar as RNStatusBar } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { WebView } from 'react-native-webview';

// Your published ORCA'S SALARY web app. All data stays in that app's database.
const APP_URL = 'https://claude.ai/artifact/Fo9k1bc8qQYi4gdEJEBhoy';
const ALLOWED = ['claude.ai', 'anthropic.com'];

export default function App() {
  const ref = useRef(null);
  const [canGoBack, setCanGoBack] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (canGoBack && ref.current) { ref.current.goBack(); return true; }
      return false;
    });
    return () => sub.remove();
  }, [canGoBack]);

  const onRequest = useCallback((req) => {
    try {
      const host = new URL(req.url).hostname;
      if (ALLOWED.some((h) => host === h || host.endsWith('.' + h))) return true;
    } catch (e) {}
    Linking.openURL(req.url).catch(() => {});
    return false;
  }, []);

  return (
    <SafeAreaView style={styles.root}>
      <StatusBar style="light" backgroundColor="#081226" />
      {failed ? (
        <View style={styles.center}>
          <Text style={styles.title}>ORCA’S SALARY</Text>
          <Text style={styles.msg}>Could not load. Check your internet connection.</Text>
          <TouchableOpacity style={styles.btn} onPress={() => { setFailed(false); ref.current && ref.current.reload(); }}>
            <Text style={styles.btnTx}>Retry</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <WebView
          ref={ref}
          source={{ uri: APP_URL }}
          style={styles.web}
          javaScriptEnabled
          domStorageEnabled
          sharedCookiesEnabled
          thirdPartyCookiesEnabled
          setSupportMultipleWindows={false}
          startInLoadingState
          renderLoading={() => (
            <View style={styles.center}><ActivityIndicator size="large" color="#d9ab3c" /></View>
          )}
          onNavigationStateChange={(s) => setCanGoBack(s.canGoBack)}
          onShouldStartLoadWithRequest={onRequest}
          onError={() => setFailed(true)}
          onHttpError={(e) => { if (e.nativeEvent.statusCode >= 500) setFailed(true); }}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#081226', paddingTop: Platform.OS === 'android' ? RNStatusBar.currentHeight || 0 : 0 },
  web: { flex: 1, backgroundColor: '#081226' },
  center: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center', backgroundColor: '#081226', padding: 24 },
  title: { color: '#f3d27a', fontSize: 24, fontWeight: '800', marginBottom: 12 },
  msg: { color: '#93a0bd', textAlign: 'center', marginBottom: 16 },
  btn: { backgroundColor: '#d9ab3c', paddingVertical: 10, paddingHorizontal: 24, borderRadius: 10 },
  btnTx: { color: '#1a1405', fontWeight: '700' },
});
