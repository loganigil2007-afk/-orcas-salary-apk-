# ORCA'S SALARY – Android wrapper

Minimal Expo WebView app that opens the published ORCA'S SALARY web app
(https://claude.ai/artifact/Fo9k1bc8qQYi4gdEJEBhoy). The salary app and its database are NOT
part of this project and are not changed. Android package: com.orcas.salary.

Build an installable APK with EAS: profile "preview" (buildType apk).
To point at a different URL, edit APP_URL in App.js.
